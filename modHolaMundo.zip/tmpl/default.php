<?php 

defined('_JEXEC') or die; ?>

<?php echo $hola; ?>