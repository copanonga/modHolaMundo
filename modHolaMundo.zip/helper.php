<?php

class ModHolaMundoHelper
{
      
    public static function getHola($params)
    {
        return 'Hola mundo!';
    }
    
}